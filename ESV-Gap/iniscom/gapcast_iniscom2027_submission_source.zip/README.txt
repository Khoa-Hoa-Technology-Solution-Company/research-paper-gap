Anonymous INISCOM 2027 submission source.

Build: pdflatex main_submission; bibtex main_submission; pdflatex main_submission; pdflatex main_submission.
Generated tables and plot data are already included.
The named-author branch has been removed. Standard bibliographic citations retain their authors.
ALT_TEXT.md supplies descriptions for the accessibility workflow; the PDF is not a tagged-accessibility PDF.
